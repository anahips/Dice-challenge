// Challenge 1
// Create an array weekDays with all days of the week, console log the array

// Challenge 2
// Log ‘Monday’ and ‘Sunday’

// Challenge 3
// Change ‘Sunday’ by ‘Funday’
// Log the array

// Challenge 4
// Remove Monday and Tuesday
// Log the array

// Challenge 5
// Log every day of the week this way:`Temperature on Monday is 18 degrees’
