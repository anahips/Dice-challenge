let country = "Guinea Bissau";
country.replace(" ", "-");
console.log(`I live in ${country}`);
let city = " Sydney   ";
let place = "School";
let attraction = "Opera House";
